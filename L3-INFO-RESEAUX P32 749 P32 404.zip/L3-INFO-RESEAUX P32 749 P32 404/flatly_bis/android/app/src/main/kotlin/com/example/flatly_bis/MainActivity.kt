package com.example.flatly_bis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
