import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AcountPage extends StatelessWidget {
  final String uid;

  const AcountPage({required this.uid, Key? key}) : super(key: key);

  Future<void> toggleAccountStatus(BuildContext context, bool isActive) async {
    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).update({
        'isActive': isActive,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(isActive ? 'Compte activé' : 'Compte désactivé')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur de mise à jour : $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('État du compte')),
      body: StreamBuilder<DocumentSnapshot>(
        stream:
            FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
                child:
                    CircularProgressIndicator()); // Centré pour meilleur affichage
          }

          if (snapshot.hasError) {
            return Center(child: Text('Erreur : ${snapshot.error}'));
          }

          if (!snapshot.hasData || !snapshot.data!.exists) {
            print('ID du document : $uid');

            return Center(child: Text('Le document n\'existe pas'));
          }

          final userData = snapshot.data!;
          final isActive = userData['isActive'] ?? false;

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'État du compte : ${isActive ? "Actif" : "Désactivé"}',
                  style: TextStyle(
                      fontSize: 18,
                      color: isActive ? Colors.green : Colors.red),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => toggleAccountStatus(context, !isActive),
                  child: Text(
                      isActive ? 'Désactiver le compte' : 'Activer le compte'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
