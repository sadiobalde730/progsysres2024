import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ProductDetailsPage extends StatefulWidget {
  final String productId;
  final String name;
  final double price;
  final String imageUrl;
  final String description;

  const ProductDetailsPage({
    required this.productId,
    required this.name,
    required this.price,
    required this.imageUrl,
    required this.description,
    Key? key,
  }) : super(key: key);

  @override
  _ProductDetailsPageState createState() => _ProductDetailsPageState();
}

class _ProductDetailsPageState extends State<ProductDetailsPage> {
  int quantity = 1;

  void _placeOrder() async {
    await FirebaseFirestore.instance.collection('orders').add({
      'productId': widget.productId,
      'productName': widget.name,
      'quantity': quantity,
      'totalPrice': widget.price * quantity,
      'orderDate': DateTime.now(),
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Commande passée avec succès !')),
    );

    Navigator.pop(context); // Retour à la page précédente
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Détails des proprietés'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            widget.imageUrl.isNotEmpty
                ? Image.network(
                    widget.imageUrl,
                    height: 200,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  )
                : const Icon(Icons.image_not_supported, size: 200),
            const SizedBox(height: 16),
            Text(widget.name, style: const TextStyle(fontSize: 24)),
            const SizedBox(height: 8),
            Text('Prix : \$${widget.price.toStringAsFixed(2)}',
                style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            Text(widget.description, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 16),
            Row(
              children: [
                const Text("Quantité :", style: TextStyle(fontSize: 18)),
                IconButton(
                  icon: const Icon(Icons.remove),
                  onPressed: () {
                    if (quantity > 1) {
                      setState(() {
                        quantity--;
                      });
                    }
                  },
                ),
                Text(quantity.toString(), style: const TextStyle(fontSize: 18)),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      quantity++;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            Center(
              child: ElevatedButton(
                onPressed: _placeOrder,
                child: const Text("Passer commande"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
