import 'package:flatly_bis/addProductPage.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TableauDeBord extends StatefulWidget {
  final String uid;
  TableauDeBord({required this.uid, Key? key}) : super(key: key);
  @override
  _TableauDeBordState createState() => _TableauDeBordState();
}

class _TableauDeBordState extends State<TableauDeBord> {
  int _productCount = 0;

  @override
  void initState() {
    super.initState();
    _fetchProductCount();
  }

  Future<void> _fetchProductCount() async {
    // Obtenez le nombre total de produits dans Firestore
    final querySnapshot =
        await FirebaseFirestore.instance.collection('products').get();
    setState(() {
      _productCount = querySnapshot.docs.length;
    });
  }

  void _navigateToAddProductPage() async {
    // Naviguer vers la page d'ajout de produit
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddProductPage(uid: widget.uid)),
    );

    // Recalculer le compteur après le retour
    _fetchProductCount();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tableau de bord'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Mes proprietés  :\nVos proprietés sont au nombre de  $_productCount',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.blue,
        onPressed: _navigateToAddProductPage,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}
