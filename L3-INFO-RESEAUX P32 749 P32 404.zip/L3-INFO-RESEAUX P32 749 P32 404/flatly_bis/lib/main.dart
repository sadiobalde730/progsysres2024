import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'myLoginPage.dart'; // Page de connexion
import 'pageProprietaire.dart'; // Page propriétaire
import 'pageUser.dart'; // Page utilisateur
import 'pageVisiteur.dart'; // Page visiteur
import 'homePage.dart'; // Page de sélection de rôle
import 'pageDetaille.dart'; // Page des coordonnées personnelles

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: /* LoginPage(),// */ Dispatcher(),
    );
  }
}

class Dispatcher extends StatelessWidget {
  const Dispatcher({super.key});

  Future<Map<String, dynamic>?> _fetchUserData(String uid) async {
    final doc =
        await FirebaseFirestore.instance.collection('users').doc(uid).get();
    return doc.exists ? doc.data() : null;
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          if (!snapshot.hasData) {
            return LoginPage(); // Utilisateur non connecté
          }

          // Utilisateur authentifié
          final user = snapshot.data as User;
          return FutureBuilder<Map<String, dynamic>?>(
            future: _fetchUserData(user.uid),
            builder: (context, userDataSnapshot) {
              if (userDataSnapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              final userData = userDataSnapshot.data;

              if (userData == null || userData.containsKey('role')) {
                // Si les données personnelles ou le rôle manquent
                if (userData == null || userData.isEmpty) {
                  return UserDetailsPage(uid: user.uid);
                }
                if (!userData.containsKey('role'))
                  return RoleSelectionPage(uid: user.uid);
              }

              final role = userData['role'];

              if (role == 'owner') {
                return OwnerPage(uid: user.uid);
              } else if (role == 'user') {
                return UserPage(uid: user.uid);
              } else if (role == 'guest') {
                return GuestPage(uid: user.uid);
              } else {
                return const Center(child: Text('Rôle invalide.'));
              }
            },
          );
        } else {
          return const Center(child: CircularProgressIndicator());
        }
      },
    );
  }
}
