import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flatly_bis/pageProprietaire.dart';
import 'package:flatly_bis/pageUser.dart';
import 'package:flatly_bis/pageVisiteur.dart';

class RoleSelectionPage extends StatelessWidget {
  final String uid;

  const RoleSelectionPage({required this.uid, Key? key}) : super(key: key);

  void _selectRole(BuildContext context, String role) async {
    await FirebaseFirestore.instance.collection('users').doc(uid).update({
      'role': role,
    });

    // Navigation directe en fonction du rôle choisi
    Widget targetPage;
    if (role == 'owner') {
      targetPage = OwnerPage(uid: uid);
    } else if (role == 'user') {
      targetPage = UserPage(uid: uid);
    } else {
      targetPage = GuestPage(uid: uid);
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => targetPage),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Choisissez votre rôle')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            GestureDetector(
              onTap: () => _selectRole(context, 'owner'),
              child: Card(
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Icon(Icons.business, size: 40, color: Colors.blue),
                      SizedBox(width: 16),
                      Text('Propriétaire', style: TextStyle(fontSize: 18)),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () => _selectRole(context, 'user'),
              child: Card(
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Icon(Icons.person, size: 40, color: Colors.green),
                      SizedBox(width: 16),
                      Text('Utilisateur', style: TextStyle(fontSize: 18)),
                    ],
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () => _selectRole(context, 'guest'),
              child: Card(
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Icon(Icons.visibility, size: 40, color: Colors.orange),
                      SizedBox(width: 16),
                      Text('Visiteur', style: TextStyle(fontSize: 18)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
