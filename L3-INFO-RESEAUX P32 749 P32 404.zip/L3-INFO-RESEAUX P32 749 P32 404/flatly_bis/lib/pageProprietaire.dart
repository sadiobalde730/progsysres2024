import 'package:flutter/material.dart';
import 'package:fluentui_icons/fluentui_icons.dart';
import 'package:flatly_bis/acountVisitor.dart';
/*import 'package:flatly/addProductPage.dart';*/
import 'package:flatly_bis/consultationCommande.dart';
import 'package:flatly_bis/tableauDeBord.dart';

class OwnerPage extends StatefulWidget {
  final String uid;

  const OwnerPage({required this.uid, Key? key}) : super(key: key);

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  late final String uid;
  late List<Widget> appScreens; // Déclare la liste comme late

  @override
  void initState() {
    super.initState();
    uid = widget.uid; // Initialise uid avec widget.uid
    appScreens = [
      /*AddProductPage(uid: uid),
      const ViewOrdersPage(),
      AcountPage(uid: uid), // Utilise uid après son initialisation*/
      TableauDeBord(uid: uid),
      const ViewOrdersPage(),
      AcountPage(uid: uid), // Utilise uid après son initialisation
    ];
  }

  int _selectedIdex = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIdex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Propriétaire')),
      body: appScreens[_selectedIdex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIdex,
        onTap: _onItemTapped,
        showSelectedLabels: false,
        selectedItemColor: Colors.blueGrey,
        unselectedItemColor: const Color(0xFF526400),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(FluentSystemIcons.ic_fluent_building_regular),
            activeIcon: Icon(FluentSystemIcons.ic_fluent_building_filled),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon:
                Icon(FluentSystemIcons.ic_fluent_channel_notifications_regular),
            activeIcon:
                Icon(FluentSystemIcons.ic_fluent_channel_notifications_filled),
            label: "notifs",
          ),
          BottomNavigationBarItem(
            icon: Icon(FluentSystemIcons.ic_fluent_person_regular),
            activeIcon: Icon(FluentSystemIcons.ic_fluent_person_filled),
            label: "Profile",
          ),
        ],
      ),
    );
  }
}
