import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AddProductPage extends StatefulWidget {
  final String uid;
  const AddProductPage({required this.uid, Key? key}) : super(key: key);
  @override
  _AddProductPageState createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  File? _image;
  final _nameController = TextEditingController();
  final _adresseController = TextEditingController();
  final _priceController = TextEditingController();
  final _descriptionController = TextEditingController();

  Future<void> _pickImage() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<String?> _uploadImageToCloudinary(File imageFile) async {
    final url =
        Uri.parse('https://api.cloudinary.com/v1_1/<cloud_name>/image/upload');
    final request = http.MultipartRequest('POST', url)
      ..fields['upload_preset'] = '<upload_preset>'
      ..files.add(await http.MultipartFile.fromPath('file', imageFile.path));

    final response = await request.send();
    if (response.statusCode == 200) {
      final responseBody = await response.stream.bytesToString();
      final data = jsonDecode(responseBody);
      return data['secure_url'];
    }
    return null;
  }

  Future<void> _addProduct() async {
    String name = _nameController.text.trim();
    String addr = _adresseController.text.trim();
    double price = double.tryParse(_priceController.text.trim()) ?? 0.0;
    String description = _descriptionController.text.trim();

    if (name.isNotEmpty && price > 0 && addr.isNotEmpty && _image != null) {
      // Upload de l'image
      String? imageUrl = await _uploadImageToCloudinary(_image!);

      if (imageUrl != null) {
        // Enregistrement du produit dans Firestore
        await FirebaseFirestore.instance.collection('products').add({
          'name': name,
          'address': addr,
          'description': description,
          'price': price,
          'imageUrl': imageUrl,
          'ownerId': widget.uid,
        });

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Produit ajouté avec succès !'),
        ));

        Navigator.pop(context); // Retour à la page précédente
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Erreur lors de l\'upload de l\'image.'),
        ));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content:
            Text('Veuillez remplir tous les champs et sélectionner une image.'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Ajouter de proprietés')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
                controller: _nameController,
                decoration: InputDecoration(labelText: 'Nom du proprieté')),
            TextField(
                controller: _adresseController,
                decoration:
                    InputDecoration(labelText: 'Adresse du proprietés')),
            TextField(
                controller: _priceController,
                decoration: InputDecoration(labelText: 'Prix')),
            TextField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Description')),
            SizedBox(height: 10),
            _image != null
                ? Image.file(_image!, height: 150, width: 150)
                : TextButton(
                    onPressed: _pickImage, child: Text('Choisir une image')),
            SizedBox(height: 20),
            ElevatedButton(onPressed: _addProduct, child: Text('Ajouter ')),
          ],
        ),
      ),
    );
  }
}
