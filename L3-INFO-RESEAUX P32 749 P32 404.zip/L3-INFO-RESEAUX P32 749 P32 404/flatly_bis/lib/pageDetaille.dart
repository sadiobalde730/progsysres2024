import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flatly_bis/homePage.dart';

class UserDetailsPage extends StatefulWidget {
  final String uid;

  const UserDetailsPage({required this.uid, Key? key}) : super(key: key);

  @override
  _UserDetailsPageState createState() => _UserDetailsPageState();
}

class _UserDetailsPageState extends State<UserDetailsPage> {
  final _formKey = GlobalKey<FormState>();
  String _name = '';
  String _surname = '';
  String _birthDate = '';

  Future<void> _saveUserDetails() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      await FirebaseFirestore.instance.collection('users').doc(widget.uid).set({
        'isActive': true,
        'name': _name,
        'surname': _surname,
        'birthDate': _birthDate,
        'role': null, // Pas encore de rôle attribué
        'createdAt': Timestamp.now(),
      });

      // Naviguer vers RoleSelectionPage avec l'UID
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => RoleSelectionPage(uid: widget.uid),
        ),
      );
    }
  }

  String getUid() {
    return widget.uid;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Vos coordonnées')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Nom'),
                validator: (value) =>
                    value!.isEmpty ? 'Entrez votre nom' : null,
                onSaved: (value) => _name = value!,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Prénom'),
                validator: (value) =>
                    value!.isEmpty ? 'Entrez votre prénom' : null,
                onSaved: (value) => _surname = value!,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Date de naissance'),
                validator: (value) =>
                    value!.isEmpty ? 'Entrez votre date de naissance' : null,
                onSaved: (value) => _birthDate = value!,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveUserDetails,
                child: Text('Suivant'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
