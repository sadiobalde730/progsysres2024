import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class VisitorSearchPage extends StatefulWidget {
  @override
  _VisitorSearchPageState createState() => _VisitorSearchPageState();
}

class _VisitorSearchPageState extends State<VisitorSearchPage> {
  String searchQuery = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          decoration: InputDecoration(
            hintText: 'Rechercher de proprietés...',
            border: InputBorder.none,
            hintStyle: TextStyle(color: Colors.white70),
          ),
          style: TextStyle(color: Colors.white),
          onChanged: (value) {
            setState(() {
              searchQuery = value.toLowerCase();
            });
          },
        ),
        backgroundColor: Colors.blue,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('products').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text(
                'Aucun proprieté trouvé.',
                style: TextStyle(fontSize: 16),
              ),
            );
          }

          final products = snapshot.data!.docs.where((product) {
            final name = product['name']?.toString().toLowerCase() ?? '';
            return name.contains(searchQuery);
          }).toList();

          if (products.isEmpty) {
            return Center(
              child: Text(
                'Aucun proprieté correspondant à votre recherche.',
                style: TextStyle(fontSize: 16),
              ),
            );
          }

          return ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              final name = product['name'] ?? 'Nom non spécifié';
              final price = product['price'] ?? 0.0;
              final imageUrl = product['imageUrl'] ?? '';

              return Card(
                margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: ListTile(
                  leading: imageUrl.isNotEmpty
                      ? Image.network(
                          imageUrl,
                          width: 50,
                          height: 50,
                          fit: BoxFit.cover,
                        )
                      : Icon(Icons.image_not_supported, size: 50),
                  title: Text(name, style: TextStyle(fontSize: 18)),
                  subtitle: Text('Prix : \$${price.toStringAsFixed(2)}'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
