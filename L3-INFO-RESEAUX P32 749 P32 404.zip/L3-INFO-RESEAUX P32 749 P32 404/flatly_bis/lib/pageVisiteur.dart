import 'package:fluentui_icons/fluentui_icons.dart';
import 'package:flutter/material.dart';
import 'package:flatly_bis/acountVisitor.dart';
import 'package:flatly_bis/searchVisitor.dart';
import 'package:flatly_bis/pageProduitVisitor.dart';

class GuestPage extends StatefulWidget {
  final String uid;

  const GuestPage({required this.uid, Key? key}) : super(key: key);
  @override
  State<GuestPage> createState() => _GuestPageState();
}

class _GuestPageState extends State<GuestPage> {
  late final String uid;
  late List<Widget> appScreens; // Déclare la liste comme late

  @override
  void initState() {
    super.initState();
    uid = widget.uid; // Initialise uid avec widget.uid
    appScreens = [
      /*VisitorProductPage(),
      VisitorSearchPage(),
      AcountPage(uid: uid), // Utilise uid après son initialisation*/
      VisitorProductPage(),
      VisitorSearchPage(),
      AcountPage(uid: uid), // Utilise uid après son initialisation
    ];
  }

  int _selectedIdex = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIdex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text("Acceuil-Visiteur")),
      ),
      body: appScreens[_selectedIdex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIdex,
        onTap: _onItemTapped,
        showSelectedLabels: false,
        selectedItemColor: Colors.blueGrey,
        unselectedItemColor: const Color(0xFF526400),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(FluentSystemIcons.ic_fluent_home_regular),
            activeIcon: Icon(FluentSystemIcons.ic_fluent_home_filled),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(FluentSystemIcons.ic_fluent_search_regular),
            activeIcon: Icon(FluentSystemIcons.ic_fluent_search_filled),
            label: "Search",
          ),
          BottomNavigationBarItem(
            icon: Icon(FluentSystemIcons.ic_fluent_person_regular),
            activeIcon: Icon(FluentSystemIcons.ic_fluent_person_filled),
            label: "Profil",
          ),
        ],
      ),
    );
  }
}
