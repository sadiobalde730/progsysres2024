const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: 'da9fobhud',  // Remplacez par votre nom de cloud
  api_key: '499865789819754',       // Remplacez par votre clé API
  api_secret: 'SMf9aTTAT_JUBgIKZbiIyZ_CiOE'  // Remplacez par votre secret API
});

console.log('Cloudinary est configuré !');
